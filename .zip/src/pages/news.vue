<template>
  <div class="news">news</div>
</template>
<script setup lang="ts">

</script>
<style lang="less" scoped>
</style>
