<template>
  <div class="list">list</div>
</template>
<script setup lang="ts">

</script>
<style lang="less" scoped>
</style>
