<template>
  <div class="home">home</div>
</template>
<script setup lang="ts">

</script>
<style lang="less" scoped>
</style>
