// 用户数据类型
export interface UserType{
    role:string,
    token:string;
    account:string
}